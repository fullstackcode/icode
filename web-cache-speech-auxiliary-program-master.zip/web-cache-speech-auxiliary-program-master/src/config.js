/*! React Starter Kit | MIT License | http://www.reactstarterkit.com/ */

export default {
  googleAnalyticsId: 'UA-XXXXX-X',
};
